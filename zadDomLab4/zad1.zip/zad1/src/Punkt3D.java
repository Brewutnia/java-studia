public class Punkt3D extends Punkt2D {
    int z;
    public Punkt3D (int x, int y, int z){
        this.x = x;
        this.y = y;
        this.z = z;
    }

}
