import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        Okienko okienko = new Okienko();
        okienko.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        okienko.setVisible(true);
    }
}